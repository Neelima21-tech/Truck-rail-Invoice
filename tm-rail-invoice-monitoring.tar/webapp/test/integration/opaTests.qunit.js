/* global QUnit */

sap.ui.require(["com/wl/tm/largereport/railedi/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
