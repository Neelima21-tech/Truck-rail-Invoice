sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    "sap/ui/core/BusyIndicator",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"

], (Controller,MessageBox,BusyIndicator,Filter,FilterOperator) => {
    "use strict";

    return Controller.extend("com.wl.tm.largereport.railedi.controller.View1", {
        onInit() {
          this.oDataModel = this.getOwnerComponent().getModel();
          var oJsonModel = new sap.ui.model.json.JSONModel([]);
          this.getView().setModel(oJsonModel, "chartData");
          this.apiCalling();
        },
        apiCalling: function () {
          var sAuthModel = this.getOwnerComponent().getModel("ZTM_BND_TRUCK_RAIL_AUTH");
          var user = sap.ushell.Container.getService("UserInfo").getId();
          //var user = "KKANCHAN";
          sap.ui.core.BusyIndicator.show();
          var aFilter = [];

          aFilter.push(new Filter({
            path: "edit",
            operator: FilterOperator.EQ,
            value1: "X"
          }));
          sAuthModel.read("/Auth",
          //sAuthModel.read("/Auth(vkorg='',usnam='" + user + "')",
            {
              filters: aFilter,
            
              success: function (oResponse) {
                this.getOwnerComponent().getModel("localModel").setProperty("/action",oResponse.results[0].status)
                sap.ui.core.BusyIndicator.hide();
              }.bind(this),
              error: function (oError) {
                sap.ui.core.BusyIndicator.hide();
                MessageBox.error(oError.message);
              }.bind(this)
            });
        },
        getSelectedDate: function (key) {
          if (key === "0") { return "015"; }
          if (key === "1") { return "030"; }
          if (key === "2") { return "060"; }
          if (key === "3") { return "090"; }
          if (key === "4") { return "180"; }
          if (key === "5") { return "001"; }
        },
        onChangeIconTab: function (oEvent) {
          if(oEvent.getParameter("key")==="graph"){
          this.graphCallingRail();
          }
        },
        graphCallingRail: function () {
          var oModel = this.getOwnerComponent().getModel();
          var aFilter = [];
          aFilter.push(new Filter({
            path: "date_sel",
            operator: FilterOperator.EQ,
            value1: this.getSelectedDate(this.getView().byId("dateSelectRail").getSelectedKey())
          }));
          aFilter.push(new Filter({
            path: "By_Carr_prodtype",
            operator: FilterOperator.EQ,
            value1: this.getView().byId("radioRail").getSelectedIndex() === 0 ? "x" : ""
          }));
          sap.ui.core.BusyIndicator.show();
          oModel.read("/ZTM_CDS_I_GRAPH_RAIL",
            {
              urlParameters: {
                "$top": 10
              },
              filters: aFilter,
              success: function (oResponse) {
                var oJsonModel = this.getView().getModel("chartData");
                oJsonModel.setData(oResponse.results);
                this._setAddGraphSettings(this.getView().byId("vizFramerail"), "rail_graph_title","rail_cat_axis_lbl", "rail_legend_lbl");
                sap.ui.core.BusyIndicator.hide();
              }.bind(this),
              error: function (oError) {
                sap.ui.core.BusyIndicator.hide();
                MessageBox.error(oError.message);
              }.bind(this)
            });
        },
        //function to set the graph settings 
		_setAddGraphSettings: function (oVizFrame,sTitle,sCategoryAxisLbl,sLegendLbl) {
			//this.getView().getModel( "chartData").refresh(true); 
			var vizProperties = {
				interaction: {
					zoom: {
						enablement: "disabled"
					},
					selectability: {
						mode: "EXCLUSIVE"
					}
				},
				valueAxis: {
					title: {
						visible: true,
						text:"$"
					},
					visible: true,
					axisLine: {
						visible: true
					},
					label: {
						linesOfWrap: 2,
						visible: true,
						style: {
							fontSize: "10px"
						}
					}
				},
				categoryAxis: {
					title: {
						visible: true ,
						text:this.changei18n(sCategoryAxisLbl)
					},
					label: {
						linesOfWrap: 2,
						rotation: "fixed",
						angle: 0,
						style: {
							fontSize: "12px"
						}
					},
					axisTick: {
						shortTickVisible: false
					}
				},
				title: {
					text: this.changei18n(sTitle),
					visible: true
				},
				legend: {
					visible: true,
					title:{
						text:this.changei18n(sLegendLbl),
						visible:true
					}
				},
				plotArea: {
					colorPalette: ["#007181"],
					gridline: {
						visible: true
					},
					dataLabel: {
						visible: true,
						style: {
							fontWeight: 'bold'
						},
						hideWhenOverlap: false
					} 
				}
			};

			oVizFrame.setVizProperties(vizProperties);
		},
        changei18n:function(sText,sPlaceholder)
        {
          var oResourceBundle=this.getOwnerComponent().getModel("i18n");
          var cText=oResourceBundle.getResourceBundle().getText(sText,sPlaceholder);
          return cText;
        },
        onPress:function(oEvent){
            var payload=[];
            var sEntity;
            var sButtonText=oEvent.getSource().getProperty("text");
           // var sPayload={};
           var sTable = this.getView().byId("reportTable");
           var sIndex = this.getView().byId("reportTable").getSelectedIndex();
                    if (sIndex === -1) {
                        MessageBox.information(this.changei18n("selectrow"));
                        return;
                    }
                   // var sObject = sTable.getContextByIndex(sIndex).getObject()
                    var sRow=this.getView().byId("reportTable").getSelectedIndices();
                    sRow.forEach((index) => {
                        var sdata=sTable.getContextByIndex(index).getObject();
                        var aCells = sTable.getRows()[index].getCells(),
                        sUserNotes = "";
                        aCells.forEach(cell => {
                          if (cell && cell.mBindingInfos && cell.mBindingInfos.value && cell.mBindingInfos.value.binding && cell.mBindingInfos.value.binding.sPath === "UserNotes") {
                            sUserNotes = cell.getValue();
                            return;
                          }
                        });

              var sPayload;
              sPayload={
                "IDOCNumber" : sdata.IDOCNumber,
                // "CreatedOn" : sdata.CreatedOn !="" ? sap.ui.core.format.DateFormat.getDateTimeInstance({ pattern: "yyyy-MM-dd\'T\'HH:mm:ss" }).format(new Date(sdata.CreatedOn)) : "",
                "CreatedOn" : sdata.CreatedOn !="" ? this.formatDate(sdata.CreatedOn) : "",
                "IDOCStatus" : sdata.IDOCStatus,
                "Direction" : sdata.Direction,
                "MessageType" : sdata.MessageType,
                "BasicType" : sdata.BasicType,
                "SenderPort" : sdata.SenderPort,
                "Currency" :sdata.Currency,
                "UserNotes" : sUserNotes
    
              }
              if(sButtonText==="Save"){
                sEntity="/ZTM_CDS_I_RAIL_EDI_E0343";
              
            }
            else{
              sEntity="/ZTM_CDS_I_RAIL_EDI_IGNORE";
             
          }
              payload.push(sPayload);
                    });
           this.onPost(payload,sEntity);
        },
        //TO Format date of CreatedOn
        formatDate: function (oDate) {
          if (!oDate) {
              return oDate;
          }
          else {
             
              // var dateString = oDate.toISOString(); 
              // var dateObj = new Date(dateString);
              var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
                UTC:true,
                  pattern: "yyyy-MM-dd\'T\'HH:mm:ss"

              });
              var formattedDate = oDateFormat.format(oDate);    
              return formattedDate; 
          }
      },
        onPost:function(finalPayload,sEntity)
        {
          
          var oModel= this.getOwnerComponent().getModel();
         var aDeferredGroups = oModel.getDeferredGroups();
          if (!aDeferredGroups.includes("gid")) {
            aDeferredGroups = aDeferredGroups.concat(["gid"]);
            oModel.setDeferredGroups(aDeferredGroups);
          }
          
          BusyIndicator.show();
          finalPayload.forEach(
              function (payload, idx) {
                
                oModel.create(sEntity, payload, {
                  groupId: "gid",
                  success: function (oData, oHdr) {             
                   // console.log("success-create");
                  }.bind(this),
                  error: function (oResponse, oHdr) {
                    
                   // console.log("error-create");
                   
                  }.bind(this),
                });
              }.bind(this)
            );
    
            oModel.submitChanges({
              groupId: "gid",
              success: function (oData) {
               // var filterData=this.getOwnerComponent().getModel("local").getProperty("/filterData");
         
              //this.getOwnerComponent().getModel("local").setProperty("/filterData",filterData);
              //this.getOwnerComponent().getModel("local").setProperty("/logVisible",true);
               
              MessageBox.information("Successfull");  
              
              //this.onReset();
                BusyIndicator.hide();
              }.bind(this),
              error: function (oError) {
            
              MessageBox.error(oError.message); 
            
              BusyIndicator.hide();}.bind(this),
            });  
        },
        //navigate to VL22N
        onClickDelivery:function(oEvent){
          var sValue = oEvent.getSource().getProperty("text");
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
				var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
          target: {
            semanticObject: "OutboundDelivery",
            action: "displayInWebGUI"
          },
          params: {
  
            "OutboundDelivery": sValue
          }
				})) || ""; // generate the Hash
				var url = window.location.href.split('#')[0] + hash;
				sap.m.URLHelper.redirect(url, true);
				
    }



        
      //   onChangeNotes:function(oEvent){
      //     var that=this,
      //     sValue=oEvent.getParameter("value"),
      //     payload = {},
      //     sPath=oEvent.getSource().getParent().getBindingContext().getPath();
      //     payload.UserNotes = sValue;
      //     this.formUpdateBatchCall(sPath,payload,that);

      //   },
      //   formUpdateBatchCall: function (sPath, payload, oController) {

      //     var that = oController;
      //     var aDeferredGroups = that.oDataModel.getDeferredGroups();
      //     if (!aDeferredGroups.includes("gid")) {
      //         aDeferredGroups = aDeferredGroups.concat(["gid"]);
      //         that.oDataModel.setDeferredGroups(aDeferredGroups);
      //     }
      //     that.oDataModel.update(sPath, payload, {
      //         groupId: "gid",
      //         //method: "POST",
      //         success: function (oData, response) {

      //         }.bind(this),
      //         error: function (oError) {
      //             this.formUpdateBatchCall(sPath, payload, this);

      //         }.bind(this)
      //     });
      // },

    });
});